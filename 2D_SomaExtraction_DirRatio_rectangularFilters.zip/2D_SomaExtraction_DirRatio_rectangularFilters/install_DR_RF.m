
folder = fileparts(which('contents_RF.m'));

% add folders to path
addpath(...
    fullfile(folder),...
    fullfile(folder, 'data'),...
    fullfile(folder, 'fast marching tollbox_reduced'));

open(fullfile(folder,'Script.m'))

disp('all paths are added')