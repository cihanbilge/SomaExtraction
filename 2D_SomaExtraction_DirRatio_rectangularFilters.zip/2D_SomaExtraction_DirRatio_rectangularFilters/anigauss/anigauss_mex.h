#ifndef anigauss_mex_h
#define anigauss_mex_h

#include <stdio.h>

#endif /* anigauss_mex_h */
